(function () {
    // 1. INJECTION DES STYLES (CSS en JS)
    const style = document.createElement('style');
    style.textContent = `
        .ds-highlight { 
            outline: 2px dashed #ff4757 !important; 
            outline-offset: -2px !important;
            cursor: crosshair !important;
        }
        #ds-panel {
            position: fixed; top: 10px; right: 10px; z-index: 999999;
            background: #2f3542; color: white; padding: 15px;
            border-radius: 8px; font-family: sans-serif; box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            width: 200px; display: none;
        }
        .ds-btn {
            background: #5352ed; border: none; color: white; padding: 5px 10px;
            margin-top: 10px; cursor: pointer; border-radius: 4px; width: 100%;
        }
        .ds-btn:hover { background: #3742fa; }
    `;
    document.head.appendChild(style);

    // 2. CRÉATION DE L'INTERFACE
    const panel = document.createElement('div');
    panel.id = 'ds-panel';
    panel.innerHTML = `
        <strong style="display:block;margin-bottom:10px;">DOM Surgeon 🛠️</strong>
        <div id="ds-info" style="font-size:11px; color:#a4b0be; word-break:break-all;">Cible: aucune</div>
        <button class="ds-btn" id="ds-hide">Cacher l'élément</button>
        <button class="ds-btn" id="ds-reset" style="background:#747d8c">Tout réinitialiser</button>
    `;
    document.body.appendChild(panel);

    let lastEl = null;
    let selectedEl = null;

    // 3. LOGIQUE DE SURBRILLANCE
    document.addEventListener('mouseover', (e) => {
        if (panel.contains(e.target)) return;
        if (lastEl) lastEl.classList.remove('ds-highlight');
        lastEl = e.target;
        lastEl.classList.add('ds-highlight');
    });

    // 4. SÉLECTION ET OUVERTURE DU PANNEAU
    document.addEventListener('click', (e) => {
        if (panel.contains(e.target)) return;

        e.preventDefault();
        e.stopPropagation();

        selectedEl = e.target;
        panel.style.display = 'block';
        document.getElementById('ds-info').innerText = "Cible: " + selectedEl.tagName.toLowerCase() + (selectedEl.id ? '#' + selectedEl.id : '');
    }, true);

    // 5. ACTIONS DU PANNEAU
    document.getElementById('ds-hide').onclick = () => {
        if (selectedEl) {
            selectedEl.style.display = 'none';
            panel.style.display = 'none';
        }
    };

    document.getElementById('ds-reset').onclick = () => {
        window.location.reload(); // Pour le MVP, on refresh pour tout retrouver
    };

    console.log("DOM-Surgeon injecté et prêt !");
})();